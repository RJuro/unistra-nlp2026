"""
FastAPI Semantic Search over SciFact abstracts.

Uses precomputed ChromaDB + multilingual-e5-small for query encoding.
    uvicorn app:app --host 0.0.0.0 --port 7860
"""

import os
import json
from fastapi import FastAPI, Query
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from sentence_transformers import SentenceTransformer, CrossEncoder
import chromadb
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

MODEL_NAME = "intfloat/multilingual-e5-small"
RERANKER_MODEL = "cross-encoder/ms-marco-MiniLM-L-6-v2"
CHROMA_PATH = os.path.join(os.path.dirname(__file__), "data", "chroma_db")
COLLECTION_NAME = "scifact"

app = FastAPI(title="SciFact Multilingual Semantic Search")

model: SentenceTransformer = None
reranker: CrossEncoder = None
collection: chromadb.Collection = None
llm_client: OpenAI = None


@app.on_event("startup")
def startup():
    global model, reranker, collection, llm_client
    print(f"Loading model: {MODEL_NAME}")
    model = SentenceTransformer(MODEL_NAME)
    print(f"Loading reranker: {RERANKER_MODEL}")
    reranker = CrossEncoder(RERANKER_MODEL)
    print(f"Loading ChromaDB from: {CHROMA_PATH}")
    client = chromadb.PersistentClient(path=CHROMA_PATH)
    collection = client.get_collection(COLLECTION_NAME)
    print(f"Collection '{COLLECTION_NAME}': {collection.count()} documents ready.")
    api_key = os.environ.get("GROQ_API_KEY")
    if api_key:
        llm_client = OpenAI(api_key=api_key, base_url="https://api.groq.com/openai/v1")
        print("Groq LLM client initialized (OpenAI-compatible).")
    else:
        print("GROQ_API_KEY not set — /synthesize will be unavailable.")


@app.get("/")
def index():
    return FileResponse(
        os.path.join(os.path.dirname(__file__), "static", "index.html")
    )


@app.get("/search")
def search(
    q: str = Query(..., min_length=1),
    top_k: int = Query(5, ge=1, le=20),
    rerank: bool = Query(True),
):
    raw_query = q.strip()

    # Stage 1: bi-encoder retrieval
    n_candidates = min(top_k * 4, 40) if rerank else top_k
    query_embedding = model.encode(
        [f"query: {raw_query}"],
        normalize_embeddings=True,
    ).tolist()

    results = collection.query(
        query_embeddings=query_embedding,
        n_results=n_candidates,
        include=["metadatas", "distances", "documents"],
    )

    candidates = []
    for meta, dist, doc in zip(
        results["metadatas"][0],
        results["distances"][0],
        results["documents"][0],
    ):
        candidates.append(
            {
                "bi_score": round(1 - dist, 4),
                "title": meta.get("title", ""),
                "full_text": doc if doc else meta.get("text", ""),
            }
        )

    # Stage 2: cross-encoder reranking
    if rerank and candidates:
        pairs = [(raw_query, c["full_text"]) for c in candidates]
        ce_scores = reranker.predict(pairs).tolist()
        for c, score in zip(candidates, ce_scores):
            c["ce_score"] = round(score, 4)
        candidates.sort(key=lambda c: c["ce_score"], reverse=True)

    items = []
    for i, c in enumerate(candidates[:top_k]):
        item = {
            "rank": i + 1,
            "bi_score": c["bi_score"],
            "title": c["title"],
            "text": c["full_text"][:300],
            "reranked": rerank,
        }
        if rerank:
            item["ce_score"] = c.get("ce_score")
        items.append(item)

    return {"query": raw_query, "results": items}


SYNTH_SYSTEM_PROMPT = (
    "You are a scientific research assistant. Given a user query and retrieved "
    "search results from scientific abstracts, write exactly 3 sentences that "
    "synthesize the findings. Determine whether the evidence supports, contradicts, "
    "or partially answers the query. Ignore any results that are not relevant to the "
    "query — treat them as retrieval noise. Be precise and cite specific findings "
    "from the relevant results."
)


@app.get("/synthesize")
def synthesize(
    q: str = Query(..., min_length=1),
    results: str = Query(..., min_length=1),
):
    if not llm_client:
        def error_stream():
            yield "data: [ERROR] GROQ_API_KEY not configured.\n\n"
        return StreamingResponse(error_stream(), media_type="text/event-stream")

    items = json.loads(results)
    context = "\n\n".join(
        f"[Result {r['rank']}] {r['title']}\n{r['text']}"
        for r in items
    )
    user_msg = f"Query: {q}\n\nRetrieved results:\n{context}"

    def token_stream():
        try:
            stream = llm_client.chat.completions.create(
                model="openai/gpt-oss-120b",
                messages=[
                    {"role": "system", "content": SYNTH_SYSTEM_PROMPT},
                    {"role": "user", "content": user_msg},
                ],
                stream=True,
            )
            for chunk in stream:
                if not chunk.choices:
                    continue
                delta = chunk.choices[0].delta
                if delta.content:
                    # SSE uses newlines as delimiters — encode content to
                    # keep multi-line tokens in a single data field.
                    escaped = delta.content.replace("\n", "\\n")
                    yield f"data: {escaped}\n\n"
            yield "data: [DONE]\n\n"
        except Exception as e:
            yield f"data: [ERROR] {e}\n\n"

    return StreamingResponse(
        token_stream(),
        media_type="text/event-stream",
        headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"},
    )


app.mount("/static", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "static")), name="static")
