---
title: SciFact Multilingual Semantic Search
emoji: "\U0001F52C"
colorFrom: indigo
colorTo: purple
sdk: docker
app_port: 7860
---

# SciFact Multilingual Semantic Search

A deployable semantic search engine over 5,183 scientific abstracts (SciFact dataset), with **two-stage retrieval** (bi-encoder + cross-encoder reranking) and **LLM-powered AI overview** streamed via Groq.

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Get a free Groq API key

Sign up at [console.groq.com/keys](https://console.groq.com/keys) and paste your key into `.env`:

```
GROQ_API_KEY=gsk_your_actual_key_here
```

### 3. Build the vector database (one-time, ~2 min on CPU)

```bash
python precompute.py
```

This downloads the SciFact dataset, encodes all 5,183 abstracts with `multilingual-e5-small`, and saves vectors + metadata to `data/chroma_db/`.

You should see:

```
ChromaDB persisted to: .../data/chroma_db
Collection 'scifact': 5183 documents
```

### 4. Run locally

```bash
uvicorn app:app --port 7860
```

Open [localhost:7860](http://localhost:7860). Try searching `effects of vaccination` — results appear instantly, then the AI overview streams in above them.

## Deploy to Hugging Face Spaces

### Prerequisites

- A free [Hugging Face](https://huggingface.co) account
- Git with [Git LFS](https://git-lfs.com/) installed (`brew install git-lfs` on macOS)

### Steps

1. **Create a Space** at [huggingface.co/new-space](https://huggingface.co/new-space) — choose **Docker** as the SDK.

2. **Add your Groq API key** as a Space secret: go to your Space's Settings > Secrets > add `GROQ_API_KEY`.

3. **Push your code** (make sure you've already run `precompute.py`):

```bash
git init
git lfs install
git lfs track "*.sqlite3" "*.bin"
git add .
git commit -m "Initial deploy"
git remote add origin https://huggingface.co/spaces/YOUR-USERNAME/YOUR-SPACE-NAME
git push origin main
```

If the push is rejected (HF creates a default commit), pull first:

```bash
git pull origin main --rebase
git add .
git rebase --continue
git push origin main
```

4. **Wait for build** (~5-10 min). Watch the **Logs** tab. Once status shows **Running**, your app is live.

## Architecture

```
LOCAL (one-time)                         HF SPACES (runtime, CPU)
────────────────                         ────────────────────────
SciFact dataset                          Load ChromaDB + models
    ↓                                        ↓
Encode 5,183 docs ──── git push ────→    /search → bi-encoder → reranker → results
(precompute.py)                          /synthesize → Groq LLM → SSE stream
    ↓
data/chroma_db/
```

## Files

| File | Purpose |
|------|---------|
| `precompute.py` | Encodes SciFact docs into ChromaDB (run locally, one-time) |
| `app.py` | FastAPI server — search, reranking, and LLM synthesis endpoints |
| `static/index.html` | Frontend — vanilla HTML/CSS/JS with streaming AI overview |
| `requirements.txt` | Python dependencies |
| `Dockerfile` | Container config for HF Spaces |
| `.env` | Your Groq API key (never commit this — it's in `.gitignore`) |
| `.gitattributes` | Git LFS tracking for large binary files |

## How It Works

1. **Bi-encoder retrieval** — query encoded with `multilingual-e5-small`, top candidates from ChromaDB by cosine distance
2. **Cross-encoder reranking** — `ms-marco-MiniLM-L-6-v2` re-scores candidates for precision (toggle on/off in the UI)
3. **LLM synthesis** — top results + query sent to Groq (`openai/gpt-oss-120b`), 3-sentence overview streamed via SSE

## Customization Ideas

- **Different dataset:** replace `load_scifact()` in `precompute.py` with your own corpus, then re-run it
- **Different LLM:** change the model name in `app.py` (any model on [Groq](https://console.groq.com/docs/models) works)
- **More languages:** the embedding model supports 100+ languages — add more example chips in `index.html`
- **Adjust results:** change `top_k` parameter (default 5, max 20)
